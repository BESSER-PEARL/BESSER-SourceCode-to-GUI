import uvicorn
import os, json
import time as time_module
import logging
from fastapi import Depends, FastAPI, HTTPException, Request, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from pydantic_classes import *
from sql_alchemy import *

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

############################################
#
#   Initialize the database
#
############################################

def init_db():
    SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/DomainModel.db")
    # Ensure local SQLite directory exists (safe no-op for other DBs)
    os.makedirs("data", exist_ok=True)
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False
    )
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return SessionLocal

app = FastAPI(
    title="DomainModel API",
    description="Auto-generated REST API with full CRUD operations, relationship management, and advanced features",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "System", "description": "System health and statistics"},
        {"name": "DashboardV3", "description": "Operations for DashboardV3 entities"},
        {"name": "DashboardV2", "description": "Operations for DashboardV2 entities"},
        {"name": "Dashboard", "description": "Operations for Dashboard entities"},
        {"name": "Users", "description": "Operations for Users entities"},
        {"name": "StarterPage", "description": "Operations for StarterPage entities"},
    ]
)

# Enable CORS for all origins (for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or restrict to ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

############################################
#
#   Middleware
#
############################################

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests and responses."""
    logger.info(f"Incoming request: {request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time header to all responses."""
    start_time = time_module.time()
    response = await call_next(request)
    process_time = time_module.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

############################################
#
#   Exception Handlers
#
############################################

# Global exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Handle ValueError exceptions."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "error": "Bad Request",
            "message": str(exc),
            "detail": "Invalid input data provided"
        }
    )


@app.exception_handler(IntegrityError)
async def integrity_error_handler(request: Request, exc: IntegrityError):
    """Handle database integrity errors."""
    logger.error(f"Database integrity error: {exc}")

    # Extract more detailed error information
    error_detail = str(exc.orig) if hasattr(exc, 'orig') else str(exc)

    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "error": "Conflict",
            "message": "Data conflict occurred",
            "detail": error_detail
        }
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError):
    """Handle general SQLAlchemy errors."""
    logger.error(f"Database error: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "message": "Database operation failed",
            "detail": "An internal database error occurred"
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail if isinstance(exc.detail, str) else "HTTP Error",
            "message": exc.detail,
            "detail": f"HTTP {exc.status_code} error occurred"
        }
    )

# Initialize database session
SessionLocal = init_db()
# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        logger.error("Database session rollback due to exception")
        raise
    finally:
        db.close()

############################################
#
#   Global API endpoints
#
############################################

@app.get("/", tags=["System"])
def root():
    """Root endpoint - API information"""
    return {
        "name": "DomainModel API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health", tags=["System"])
def health_check():
    """Health check endpoint for monitoring"""
    from datetime import datetime
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "database": "connected"
    }


@app.get("/statistics", tags=["System"])
def get_statistics(database: Session = Depends(get_db)):
    """Get database statistics for all entities"""
    stats = {}
    stats["dashboardv3_count"] = database.query(DashboardV3).count()
    stats["dashboardv2_count"] = database.query(DashboardV2).count()
    stats["dashboard_count"] = database.query(Dashboard).count()
    stats["users_count"] = database.query(Users).count()
    stats["starterpage_count"] = database.query(StarterPage).count()
    stats["total_entities"] = sum(stats.values())
    return stats


############################################
#
#   BESSER Action Language standard lib
#
############################################


async def BAL_size(sequence:list) -> int:
    return len(sequence)

async def BAL_is_empty(sequence:list) -> bool:
    return len(sequence) == 0

async def BAL_add(sequence:list, elem) -> None:
    sequence.append(elem)

async def BAL_remove(sequence:list, elem) -> None:
    sequence.remove(elem)

async def BAL_contains(sequence:list, elem) -> bool:
    return elem in sequence

async def BAL_filter(sequence:list, predicate) -> list:
    return [elem for elem in sequence if predicate(elem)]

async def BAL_forall(sequence:list, predicate) -> bool:
    for elem in sequence:
        if not predicate(elem):
            return False
    return True

async def BAL_exists(sequence:list, predicate) -> bool:
    for elem in sequence:
        if predicate(elem):
            return True
    return False

async def BAL_one(sequence:list, predicate) -> bool:
    found = False
    for elem in sequence:
        if predicate(elem):
            if found:
                return False
            found = True
    return found

async def BAL_is_unique(sequence:list, mapping) -> bool:
    mapped = [mapping(elem) for elem in sequence]
    return len(set(mapped)) == len(mapped)

async def BAL_map(sequence:list, mapping) -> list:
    return [mapping(elem) for elem in sequence]

async def BAL_reduce(sequence:list, reduce_fn, aggregator) -> any:
    for elem in sequence:
        aggregator = reduce_fn(aggregator, elem)
    return aggregator


############################################
#
#   DashboardV3 functions
#
############################################

@app.get("/dashboardv3/", response_model=None, tags=["DashboardV3"])
def get_all_dashboardv3(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    return database.query(DashboardV3).all()


@app.get("/dashboardv3/count/", response_model=None, tags=["DashboardV3"])
def get_count_dashboardv3(database: Session = Depends(get_db)) -> dict:
    """Get the total count of DashboardV3 entities"""
    count = database.query(DashboardV3).count()
    return {"count": count}


@app.get("/dashboardv3/paginated/", response_model=None, tags=["DashboardV3"])
def get_paginated_dashboardv3(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of DashboardV3 entities"""
    total = database.query(DashboardV3).count()
    dashboardv3_list = database.query(DashboardV3).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": dashboardv3_list
    }


@app.get("/dashboardv3/search/", response_model=None, tags=["DashboardV3"])
def search_dashboardv3(
    database: Session = Depends(get_db)
) -> list:
    """Search DashboardV3 entities by attributes"""
    query = database.query(DashboardV3)


    results = query.all()
    return results


@app.get("/dashboardv3/{dashboardv3_id}/", response_model=None, tags=["DashboardV3"])
async def get_dashboardv3(dashboardv3_id: int, database: Session = Depends(get_db)) -> DashboardV3:
    db_dashboardv3 = database.query(DashboardV3).filter(DashboardV3.id == dashboardv3_id).first()
    if db_dashboardv3 is None:
        raise HTTPException(status_code=404, detail="DashboardV3 not found")

    response_data = {
        "dashboardv3": db_dashboardv3,
}
    return response_data



@app.post("/dashboardv3/", response_model=None, tags=["DashboardV3"])
async def create_dashboardv3(dashboardv3_data: DashboardV3Create, database: Session = Depends(get_db)) -> DashboardV3:


    db_dashboardv3 = DashboardV3(
        visitorsTotal=dashboardv3_data.visitorsTotal,        visitorsChangePercent=dashboardv3_data.visitorsChangePercent,        salesTotal=dashboardv3_data.salesTotal,        salesChangePercent=dashboardv3_data.salesChangePercent,        conversionRatePercent=dashboardv3_data.conversionRatePercent,        salesRatePercent=dashboardv3_data.salesRatePercent,        registrationRatePercent=dashboardv3_data.registrationRatePercent        )

    database.add(db_dashboardv3)
    database.commit()
    database.refresh(db_dashboardv3)




    return db_dashboardv3


@app.post("/dashboardv3/bulk/", response_model=None, tags=["DashboardV3"])
async def bulk_create_dashboardv3(items: list[DashboardV3Create], database: Session = Depends(get_db)) -> dict:
    """Create multiple DashboardV3 entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_dashboardv3 = DashboardV3(
                visitorsTotal=item_data.visitorsTotal,                visitorsChangePercent=item_data.visitorsChangePercent,                salesTotal=item_data.salesTotal,                salesChangePercent=item_data.salesChangePercent,                conversionRatePercent=item_data.conversionRatePercent,                salesRatePercent=item_data.salesRatePercent,                registrationRatePercent=item_data.registrationRatePercent            )
            database.add(db_dashboardv3)
            database.flush()  # Get ID without committing
            created_items.append(db_dashboardv3.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} DashboardV3 entities"
    }


@app.delete("/dashboardv3/bulk/", response_model=None, tags=["DashboardV3"])
async def bulk_delete_dashboardv3(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple DashboardV3 entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_dashboardv3 = database.query(DashboardV3).filter(DashboardV3.id == item_id).first()
        if db_dashboardv3:
            database.delete(db_dashboardv3)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} DashboardV3 entities"
    }

@app.put("/dashboardv3/{dashboardv3_id}/", response_model=None, tags=["DashboardV3"])
async def update_dashboardv3(dashboardv3_id: int, dashboardv3_data: DashboardV3Create, database: Session = Depends(get_db)) -> DashboardV3:
    db_dashboardv3 = database.query(DashboardV3).filter(DashboardV3.id == dashboardv3_id).first()
    if db_dashboardv3 is None:
        raise HTTPException(status_code=404, detail="DashboardV3 not found")

    setattr(db_dashboardv3, 'visitorsTotal', dashboardv3_data.visitorsTotal)
    setattr(db_dashboardv3, 'visitorsChangePercent', dashboardv3_data.visitorsChangePercent)
    setattr(db_dashboardv3, 'salesTotal', dashboardv3_data.salesTotal)
    setattr(db_dashboardv3, 'salesChangePercent', dashboardv3_data.salesChangePercent)
    setattr(db_dashboardv3, 'conversionRatePercent', dashboardv3_data.conversionRatePercent)
    setattr(db_dashboardv3, 'salesRatePercent', dashboardv3_data.salesRatePercent)
    setattr(db_dashboardv3, 'registrationRatePercent', dashboardv3_data.registrationRatePercent)
    database.commit()
    database.refresh(db_dashboardv3)

    return db_dashboardv3


@app.delete("/dashboardv3/{dashboardv3_id}/", response_model=None, tags=["DashboardV3"])
async def delete_dashboardv3(dashboardv3_id: int, database: Session = Depends(get_db)):
    db_dashboardv3 = database.query(DashboardV3).filter(DashboardV3.id == dashboardv3_id).first()
    if db_dashboardv3 is None:
        raise HTTPException(status_code=404, detail="DashboardV3 not found")
    database.delete(db_dashboardv3)
    database.commit()
    return db_dashboardv3






############################################
#
#   DashboardV2 functions
#
############################################

@app.get("/dashboardv2/", response_model=None, tags=["DashboardV2"])
def get_all_dashboardv2(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    return database.query(DashboardV2).all()


@app.get("/dashboardv2/count/", response_model=None, tags=["DashboardV2"])
def get_count_dashboardv2(database: Session = Depends(get_db)) -> dict:
    """Get the total count of DashboardV2 entities"""
    count = database.query(DashboardV2).count()
    return {"count": count}


@app.get("/dashboardv2/paginated/", response_model=None, tags=["DashboardV2"])
def get_paginated_dashboardv2(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of DashboardV2 entities"""
    total = database.query(DashboardV2).count()
    dashboardv2_list = database.query(DashboardV2).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": dashboardv2_list
    }


@app.get("/dashboardv2/search/", response_model=None, tags=["DashboardV2"])
def search_dashboardv2(
    database: Session = Depends(get_db)
) -> list:
    """Search DashboardV2 entities by attributes"""
    query = database.query(DashboardV2)


    results = query.all()
    return results


@app.get("/dashboardv2/{dashboardv2_id}/", response_model=None, tags=["DashboardV2"])
async def get_dashboardv2(dashboardv2_id: int, database: Session = Depends(get_db)) -> DashboardV2:
    db_dashboardv2 = database.query(DashboardV2).filter(DashboardV2.id == dashboardv2_id).first()
    if db_dashboardv2 is None:
        raise HTTPException(status_code=404, detail="DashboardV2 not found")

    response_data = {
        "dashboardv2": db_dashboardv2,
}
    return response_data



@app.post("/dashboardv2/", response_model=None, tags=["DashboardV2"])
async def create_dashboardv2(dashboardv2_data: DashboardV2Create, database: Session = Depends(get_db)) -> DashboardV2:


    db_dashboardv2 = DashboardV2(
        newMembers=dashboardv2_data.newMembers,        totalRevenue=dashboardv2_data.totalRevenue,        totalCost=dashboardv2_data.totalCost,        sales=dashboardv2_data.sales,        totalProfit=dashboardv2_data.totalProfit,        goalCompletions=dashboardv2_data.goalCompletions,        cpuTrafficPercent=dashboardv2_data.cpuTrafficPercent,        inventory=dashboardv2_data.inventory,        mentions=dashboardv2_data.mentions,        likes=dashboardv2_data.likes,        downloads=dashboardv2_data.downloads        )

    database.add(db_dashboardv2)
    database.commit()
    database.refresh(db_dashboardv2)




    return db_dashboardv2


@app.post("/dashboardv2/bulk/", response_model=None, tags=["DashboardV2"])
async def bulk_create_dashboardv2(items: list[DashboardV2Create], database: Session = Depends(get_db)) -> dict:
    """Create multiple DashboardV2 entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_dashboardv2 = DashboardV2(
                newMembers=item_data.newMembers,                totalRevenue=item_data.totalRevenue,                totalCost=item_data.totalCost,                sales=item_data.sales,                totalProfit=item_data.totalProfit,                goalCompletions=item_data.goalCompletions,                cpuTrafficPercent=item_data.cpuTrafficPercent,                inventory=item_data.inventory,                mentions=item_data.mentions,                likes=item_data.likes,                downloads=item_data.downloads            )
            database.add(db_dashboardv2)
            database.flush()  # Get ID without committing
            created_items.append(db_dashboardv2.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} DashboardV2 entities"
    }


@app.delete("/dashboardv2/bulk/", response_model=None, tags=["DashboardV2"])
async def bulk_delete_dashboardv2(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple DashboardV2 entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_dashboardv2 = database.query(DashboardV2).filter(DashboardV2.id == item_id).first()
        if db_dashboardv2:
            database.delete(db_dashboardv2)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} DashboardV2 entities"
    }

@app.put("/dashboardv2/{dashboardv2_id}/", response_model=None, tags=["DashboardV2"])
async def update_dashboardv2(dashboardv2_id: int, dashboardv2_data: DashboardV2Create, database: Session = Depends(get_db)) -> DashboardV2:
    db_dashboardv2 = database.query(DashboardV2).filter(DashboardV2.id == dashboardv2_id).first()
    if db_dashboardv2 is None:
        raise HTTPException(status_code=404, detail="DashboardV2 not found")

    setattr(db_dashboardv2, 'newMembers', dashboardv2_data.newMembers)
    setattr(db_dashboardv2, 'totalRevenue', dashboardv2_data.totalRevenue)
    setattr(db_dashboardv2, 'totalCost', dashboardv2_data.totalCost)
    setattr(db_dashboardv2, 'sales', dashboardv2_data.sales)
    setattr(db_dashboardv2, 'totalProfit', dashboardv2_data.totalProfit)
    setattr(db_dashboardv2, 'goalCompletions', dashboardv2_data.goalCompletions)
    setattr(db_dashboardv2, 'cpuTrafficPercent', dashboardv2_data.cpuTrafficPercent)
    setattr(db_dashboardv2, 'inventory', dashboardv2_data.inventory)
    setattr(db_dashboardv2, 'mentions', dashboardv2_data.mentions)
    setattr(db_dashboardv2, 'likes', dashboardv2_data.likes)
    setattr(db_dashboardv2, 'downloads', dashboardv2_data.downloads)
    database.commit()
    database.refresh(db_dashboardv2)

    return db_dashboardv2


@app.delete("/dashboardv2/{dashboardv2_id}/", response_model=None, tags=["DashboardV2"])
async def delete_dashboardv2(dashboardv2_id: int, database: Session = Depends(get_db)):
    db_dashboardv2 = database.query(DashboardV2).filter(DashboardV2.id == dashboardv2_id).first()
    if db_dashboardv2 is None:
        raise HTTPException(status_code=404, detail="DashboardV2 not found")
    database.delete(db_dashboardv2)
    database.commit()
    return db_dashboardv2






############################################
#
#   Dashboard functions
#
############################################

@app.get("/dashboard/", response_model=None, tags=["Dashboard"])
def get_all_dashboard(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    return database.query(Dashboard).all()


@app.get("/dashboard/count/", response_model=None, tags=["Dashboard"])
def get_count_dashboard(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Dashboard entities"""
    count = database.query(Dashboard).count()
    return {"count": count}


@app.get("/dashboard/paginated/", response_model=None, tags=["Dashboard"])
def get_paginated_dashboard(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Dashboard entities"""
    total = database.query(Dashboard).count()
    dashboard_list = database.query(Dashboard).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": dashboard_list
    }


@app.get("/dashboard/search/", response_model=None, tags=["Dashboard"])
def search_dashboard(
    database: Session = Depends(get_db)
) -> list:
    """Search Dashboard entities by attributes"""
    query = database.query(Dashboard)


    results = query.all()
    return results


@app.get("/dashboard/{dashboard_id}/", response_model=None, tags=["Dashboard"])
async def get_dashboard(dashboard_id: int, database: Session = Depends(get_db)) -> Dashboard:
    db_dashboard = database.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
    if db_dashboard is None:
        raise HTTPException(status_code=404, detail="Dashboard not found")

    response_data = {
        "dashboard": db_dashboard,
}
    return response_data



@app.post("/dashboard/", response_model=None, tags=["Dashboard"])
async def create_dashboard(dashboard_data: DashboardCreate, database: Session = Depends(get_db)) -> Dashboard:


    db_dashboard = Dashboard(
        newOrders=dashboard_data.newOrders,        bounceRatePercent=dashboard_data.bounceRatePercent,        userRegistrations=dashboard_data.userRegistrations,        uniqueVisitors=dashboard_data.uniqueVisitors,        directChatNewMessages=dashboard_data.directChatNewMessages        )

    database.add(db_dashboard)
    database.commit()
    database.refresh(db_dashboard)




    return db_dashboard


@app.post("/dashboard/bulk/", response_model=None, tags=["Dashboard"])
async def bulk_create_dashboard(items: list[DashboardCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Dashboard entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_dashboard = Dashboard(
                newOrders=item_data.newOrders,                bounceRatePercent=item_data.bounceRatePercent,                userRegistrations=item_data.userRegistrations,                uniqueVisitors=item_data.uniqueVisitors,                directChatNewMessages=item_data.directChatNewMessages            )
            database.add(db_dashboard)
            database.flush()  # Get ID without committing
            created_items.append(db_dashboard.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Dashboard entities"
    }


@app.delete("/dashboard/bulk/", response_model=None, tags=["Dashboard"])
async def bulk_delete_dashboard(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Dashboard entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_dashboard = database.query(Dashboard).filter(Dashboard.id == item_id).first()
        if db_dashboard:
            database.delete(db_dashboard)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Dashboard entities"
    }

@app.put("/dashboard/{dashboard_id}/", response_model=None, tags=["Dashboard"])
async def update_dashboard(dashboard_id: int, dashboard_data: DashboardCreate, database: Session = Depends(get_db)) -> Dashboard:
    db_dashboard = database.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
    if db_dashboard is None:
        raise HTTPException(status_code=404, detail="Dashboard not found")

    setattr(db_dashboard, 'newOrders', dashboard_data.newOrders)
    setattr(db_dashboard, 'bounceRatePercent', dashboard_data.bounceRatePercent)
    setattr(db_dashboard, 'userRegistrations', dashboard_data.userRegistrations)
    setattr(db_dashboard, 'uniqueVisitors', dashboard_data.uniqueVisitors)
    setattr(db_dashboard, 'directChatNewMessages', dashboard_data.directChatNewMessages)
    database.commit()
    database.refresh(db_dashboard)

    return db_dashboard


@app.delete("/dashboard/{dashboard_id}/", response_model=None, tags=["Dashboard"])
async def delete_dashboard(dashboard_id: int, database: Session = Depends(get_db)):
    db_dashboard = database.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
    if db_dashboard is None:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    database.delete(db_dashboard)
    database.commit()
    return db_dashboard






############################################
#
#   Users functions
#
############################################

@app.get("/users/", response_model=None, tags=["Users"])
def get_all_users(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    return database.query(Users).all()


@app.get("/users/count/", response_model=None, tags=["Users"])
def get_count_users(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Users entities"""
    count = database.query(Users).count()
    return {"count": count}


@app.get("/users/paginated/", response_model=None, tags=["Users"])
def get_paginated_users(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Users entities"""
    total = database.query(Users).count()
    users_list = database.query(Users).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": users_list
    }


@app.get("/users/search/", response_model=None, tags=["Users"])
def search_users(
    database: Session = Depends(get_db)
) -> list:
    """Search Users entities by attributes"""
    query = database.query(Users)


    results = query.all()
    return results


@app.get("/users/{users_id}/", response_model=None, tags=["Users"])
async def get_users(users_id: int, database: Session = Depends(get_db)) -> Users:
    db_users = database.query(Users).filter(Users.id == users_id).first()
    if db_users is None:
        raise HTTPException(status_code=404, detail="Users not found")

    response_data = {
        "users": db_users,
}
    return response_data



@app.post("/users/", response_model=None, tags=["Users"])
async def create_users(users_data: UsersCreate, database: Session = Depends(get_db)) -> Users:


    db_users = Users(
        usersShowingTo=users_data.usersShowingTo,        usersShowingFrom=users_data.usersShowingFrom,        usersTotal=users_data.usersTotal        )

    database.add(db_users)
    database.commit()
    database.refresh(db_users)




    return db_users


@app.post("/users/bulk/", response_model=None, tags=["Users"])
async def bulk_create_users(items: list[UsersCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Users entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_users = Users(
                usersShowingTo=item_data.usersShowingTo,                usersShowingFrom=item_data.usersShowingFrom,                usersTotal=item_data.usersTotal            )
            database.add(db_users)
            database.flush()  # Get ID without committing
            created_items.append(db_users.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Users entities"
    }


@app.delete("/users/bulk/", response_model=None, tags=["Users"])
async def bulk_delete_users(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Users entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_users = database.query(Users).filter(Users.id == item_id).first()
        if db_users:
            database.delete(db_users)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Users entities"
    }

@app.put("/users/{users_id}/", response_model=None, tags=["Users"])
async def update_users(users_id: int, users_data: UsersCreate, database: Session = Depends(get_db)) -> Users:
    db_users = database.query(Users).filter(Users.id == users_id).first()
    if db_users is None:
        raise HTTPException(status_code=404, detail="Users not found")

    setattr(db_users, 'usersShowingTo', users_data.usersShowingTo)
    setattr(db_users, 'usersShowingFrom', users_data.usersShowingFrom)
    setattr(db_users, 'usersTotal', users_data.usersTotal)
    database.commit()
    database.refresh(db_users)

    return db_users


@app.delete("/users/{users_id}/", response_model=None, tags=["Users"])
async def delete_users(users_id: int, database: Session = Depends(get_db)):
    db_users = database.query(Users).filter(Users.id == users_id).first()
    if db_users is None:
        raise HTTPException(status_code=404, detail="Users not found")
    database.delete(db_users)
    database.commit()
    return db_users






############################################
#
#   StarterPage functions
#
############################################

@app.get("/starterpage/", response_model=None, tags=["StarterPage"])
def get_all_starterpage(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    return database.query(StarterPage).all()


@app.get("/starterpage/count/", response_model=None, tags=["StarterPage"])
def get_count_starterpage(database: Session = Depends(get_db)) -> dict:
    """Get the total count of StarterPage entities"""
    count = database.query(StarterPage).count()
    return {"count": count}


@app.get("/starterpage/paginated/", response_model=None, tags=["StarterPage"])
def get_paginated_starterpage(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of StarterPage entities"""
    total = database.query(StarterPage).count()
    starterpage_list = database.query(StarterPage).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": starterpage_list
    }


@app.get("/starterpage/search/", response_model=None, tags=["StarterPage"])
def search_starterpage(
    database: Session = Depends(get_db)
) -> list:
    """Search StarterPage entities by attributes"""
    query = database.query(StarterPage)


    results = query.all()
    return results


@app.get("/starterpage/{starterpage_id}/", response_model=None, tags=["StarterPage"])
async def get_starterpage(starterpage_id: int, database: Session = Depends(get_db)) -> StarterPage:
    db_starterpage = database.query(StarterPage).filter(StarterPage.id == starterpage_id).first()
    if db_starterpage is None:
        raise HTTPException(status_code=404, detail="StarterPage not found")

    response_data = {
        "starterpage": db_starterpage,
}
    return response_data



@app.post("/starterpage/", response_model=None, tags=["StarterPage"])
async def create_starterpage(starterpage_data: StarterPageCreate, database: Session = Depends(get_db)) -> StarterPage:


    db_starterpage = StarterPage(
        starterCardTitle=starterpage_data.starterCardTitle,        starterCardBodyText=starterpage_data.starterCardBodyText        )

    database.add(db_starterpage)
    database.commit()
    database.refresh(db_starterpage)




    return db_starterpage


@app.post("/starterpage/bulk/", response_model=None, tags=["StarterPage"])
async def bulk_create_starterpage(items: list[StarterPageCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple StarterPage entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_starterpage = StarterPage(
                starterCardTitle=item_data.starterCardTitle,                starterCardBodyText=item_data.starterCardBodyText            )
            database.add(db_starterpage)
            database.flush()  # Get ID without committing
            created_items.append(db_starterpage.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} StarterPage entities"
    }


@app.delete("/starterpage/bulk/", response_model=None, tags=["StarterPage"])
async def bulk_delete_starterpage(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple StarterPage entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_starterpage = database.query(StarterPage).filter(StarterPage.id == item_id).first()
        if db_starterpage:
            database.delete(db_starterpage)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} StarterPage entities"
    }

@app.put("/starterpage/{starterpage_id}/", response_model=None, tags=["StarterPage"])
async def update_starterpage(starterpage_id: int, starterpage_data: StarterPageCreate, database: Session = Depends(get_db)) -> StarterPage:
    db_starterpage = database.query(StarterPage).filter(StarterPage.id == starterpage_id).first()
    if db_starterpage is None:
        raise HTTPException(status_code=404, detail="StarterPage not found")

    setattr(db_starterpage, 'starterCardTitle', starterpage_data.starterCardTitle)
    setattr(db_starterpage, 'starterCardBodyText', starterpage_data.starterCardBodyText)
    database.commit()
    database.refresh(db_starterpage)

    return db_starterpage


@app.delete("/starterpage/{starterpage_id}/", response_model=None, tags=["StarterPage"])
async def delete_starterpage(starterpage_id: int, database: Session = Depends(get_db)):
    db_starterpage = database.query(StarterPage).filter(StarterPage.id == starterpage_id).first()
    if db_starterpage is None:
        raise HTTPException(status_code=404, detail="StarterPage not found")
    database.delete(db_starterpage)
    database.commit()
    return db_starterpage








############################################
# Maintaining the server
############################################
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)



