from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator


############################################
# Enumerations are defined here
############################################

############################################
# Classes are defined here
############################################
class DashboardV3Create(BaseModel):
    visitorsTotal: int
    visitorsChangePercent: float
    salesTotal: float
    salesChangePercent: float
    conversionRatePercent: float
    salesRatePercent: float
    registrationRatePercent: float


class DashboardV2Create(BaseModel):
    newMembers: int
    totalRevenue: float
    totalCost: float
    sales: int
    totalProfit: float
    goalCompletions: int
    cpuTrafficPercent: float
    inventory: int
    mentions: int
    likes: int
    downloads: int


class DashboardCreate(BaseModel):
    newOrders: int
    bounceRatePercent: float
    userRegistrations: int
    uniqueVisitors: int
    directChatNewMessages: int


class UsersCreate(BaseModel):
    usersShowingTo: int
    usersShowingFrom: int
    usersTotal: int


class StarterPageCreate(BaseModel):
    starterCardTitle: str
    starterCardBodyText: str


