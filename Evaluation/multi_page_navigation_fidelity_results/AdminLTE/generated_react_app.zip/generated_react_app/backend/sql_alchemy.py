import enum
from typing import List as List_, Optional as Optional_
from sqlalchemy import (
    create_engine, Column as Column_, ForeignKey as ForeignKey_, Table as Table_, 
    Text as Text_, Boolean as Boolean_, String as String_, Date as Date_, 
    Time as Time_, DateTime as DateTime_, Float as Float_, Integer as Integer_, Enum
)
from sqlalchemy.orm import (
    column_property, DeclarativeBase, Mapped as Mapped_, mapped_column, relationship
)
from datetime import datetime as dt_datetime, time as dt_time, date as dt_date

class Base(DeclarativeBase):
    pass



# Tables definition for many-to-many relationships

# Tables definition
class DashboardV3(Base):
    __tablename__ = "dashboardv3"
    id: Mapped_[int] = mapped_column(primary_key=True)
    visitorsTotal: Mapped_[int] = mapped_column(Integer_)
    visitorsChangePercent: Mapped_[float] = mapped_column(Float_)
    salesTotal: Mapped_[float] = mapped_column(Float_)
    salesChangePercent: Mapped_[float] = mapped_column(Float_)
    conversionRatePercent: Mapped_[float] = mapped_column(Float_)
    salesRatePercent: Mapped_[float] = mapped_column(Float_)
    registrationRatePercent: Mapped_[float] = mapped_column(Float_)

class DashboardV2(Base):
    __tablename__ = "dashboardv2"
    id: Mapped_[int] = mapped_column(primary_key=True)
    cpuTrafficPercent: Mapped_[float] = mapped_column(Float_)
    likes: Mapped_[int] = mapped_column(Integer_)
    sales: Mapped_[int] = mapped_column(Integer_)
    newMembers: Mapped_[int] = mapped_column(Integer_)
    totalRevenue: Mapped_[float] = mapped_column(Float_)
    totalCost: Mapped_[float] = mapped_column(Float_)
    totalProfit: Mapped_[float] = mapped_column(Float_)
    goalCompletions: Mapped_[int] = mapped_column(Integer_)
    inventory: Mapped_[int] = mapped_column(Integer_)
    mentions: Mapped_[int] = mapped_column(Integer_)
    downloads: Mapped_[int] = mapped_column(Integer_)

class Dashboard(Base):
    __tablename__ = "dashboard"
    id: Mapped_[int] = mapped_column(primary_key=True)
    newOrders: Mapped_[int] = mapped_column(Integer_)
    bounceRatePercent: Mapped_[float] = mapped_column(Float_)
    userRegistrations: Mapped_[int] = mapped_column(Integer_)
    uniqueVisitors: Mapped_[int] = mapped_column(Integer_)
    directChatNewMessages: Mapped_[int] = mapped_column(Integer_)

class Users(Base):
    __tablename__ = "users"
    id: Mapped_[int] = mapped_column(primary_key=True)
    usersShowingFrom: Mapped_[int] = mapped_column(Integer_)
    usersShowingTo: Mapped_[int] = mapped_column(Integer_)
    usersTotal: Mapped_[int] = mapped_column(Integer_)

class StarterPage(Base):
    __tablename__ = "starterpage"
    id: Mapped_[int] = mapped_column(primary_key=True)
    starterCardTitle: Mapped_[str] = mapped_column(String_(100))
    starterCardBodyText: Mapped_[str] = mapped_column(String_(100))


# Database connection
DATABASE_URL = "sqlite:///DomainModel.db"  # SQLite connection
engine = create_engine(DATABASE_URL, echo=True)

# Create tables in the database
Base.metadata.create_all(engine, checkfirst=True)