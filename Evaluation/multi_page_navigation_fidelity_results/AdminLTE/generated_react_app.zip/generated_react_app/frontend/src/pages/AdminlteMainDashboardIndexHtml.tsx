import React from "react";
import { useNavigate } from "react-router-dom";
import { DataListBlock } from "../components/runtime/DataListBlock";

const AdminlteMainDashboardIndexHtml: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div id="DashboardScreen">
    <div id="DashboardContent" style={{"width": "100%", "height": "auto", "padding": "24px", "margin": "0", "fontSize": "14px", "zIndex": 0, "background": "#F4F6F9", "color": "#1F2937", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "16px"}} />
    <div id="DashboardSidebar" style={{"width": "250px", "height": "100%", "padding": "0", "margin": "0", "fontSize": "14px", "top": "0", "left": "0", "bottom": "0", "zIndex": 50, "background": "#343A40", "color": "#C2C7D0", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "8px"}} />
    <DataListBlock id="DashboardStatsList" style={{"width": "100%", "height": "auto", "padding": "16px", "margin": "0 0 16px 0", "fontSize": "14px", "zIndex": 0, "background": "#FFFFFF", "color": "#1F2937", "borderColor": "#DEE2E6", "--chart-color-palette": "default"}} dataSources={[{"name": "DashboardDataSource", "domain": "Dashboard", "fields": ["bounceRatePercent", "directChatNewMessages", "newOrders", "uniqueVisitors", "userRegistrations"]}]} />
    <div id="DashboardTitle" style={{"width": "auto", "height": "auto", "padding": "0", "margin": "0 0 20px 0", "fontSize": "24px", "zIndex": 0, "color": "#1F2937", "--chart-color-palette": "default"}} />
    <button id="NavToDashV2" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV2Screen")}>{"Dashboard v2"}</button>
    <button id="NavToDashV3" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV3Screen")}>{"Dashboard v3"}</button>
    <button id="NavToStarter" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/StarterScreen")}>{"Starter"}</button>
    <button id="NavToUsers" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/UsersScreen")}>{"Users"}</button>    </div>
  );
};

export default AdminlteMainDashboardIndexHtml;
