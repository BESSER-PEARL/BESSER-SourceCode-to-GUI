import React from "react";
import { useNavigate } from "react-router-dom";
import { DataListBlock } from "../components/runtime/DataListBlock";

const AdminlteStarterPageStarterHtml: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div id="StarterScreen">
    <button id="NavSToDash" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardScreen")}>{"Dashboard"}</button>
    <button id="NavSToDashV2" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV2Screen")}>{"Dashboard v2"}</button>
    <button id="NavSToDashV3" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV3Screen")}>{"Dashboard v3"}</button>
    <button id="NavSToUsers" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/UsersScreen")}>{"Users"}</button>
    <div id="StarterContent" style={{"width": "100%", "height": "auto", "padding": "24px", "margin": "0", "fontSize": "14px", "zIndex": 0, "background": "#F4F6F9", "color": "#1F2937", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "16px"}} />
    <DataListBlock id="StarterContentList" style={{"width": "100%", "height": "auto", "padding": "16px", "margin": "0 0 16px 0", "fontSize": "14px", "zIndex": 0, "background": "#FFFFFF", "color": "#1F2937", "borderColor": "#DEE2E6", "--chart-color-palette": "default"}} dataSources={[{"name": "StarterDataSource", "domain": "StarterPage", "fields": ["starterCardBodyText", "starterCardTitle"]}]} />
    <div id="StarterSidebar" style={{"width": "250px", "height": "100%", "padding": "0", "margin": "0", "fontSize": "14px", "top": "0", "left": "0", "bottom": "0", "zIndex": 50, "background": "#343A40", "color": "#C2C7D0", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "8px"}} />
    <div id="StarterTitle" style={{"width": "auto", "height": "auto", "padding": "0", "margin": "0 0 20px 0", "fontSize": "24px", "zIndex": 0, "color": "#1F2937", "--chart-color-palette": "default"}} />    </div>
  );
};

export default AdminlteStarterPageStarterHtml;
