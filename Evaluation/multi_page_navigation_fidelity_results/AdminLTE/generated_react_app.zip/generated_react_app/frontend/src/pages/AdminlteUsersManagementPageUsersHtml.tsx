import React from "react";
import { useNavigate } from "react-router-dom";
import { DataListBlock } from "../components/runtime/DataListBlock";

const AdminlteUsersManagementPageUsersHtml: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div id="UsersScreen">
    <button id="AddUserButton" style={{"width": "auto", "height": "38px", "padding": "6px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "background": "#007BFF", "color": "#FFFFFF", "--chart-color-palette": "default"}}>{"Add User"}</button>
    <form id="AddUserForm" onSubmit={(e) => { e.preventDefault(); }}>
      <div style={{"marginBottom": "16px"}}>
      <label htmlFor="UserSearchInput" style={{"display": "block", "marginBottom": "5px", "fontWeight": "500"}}>{"UserSearchInput"}</label>
      <input type="text" id="UserSearchInput" style={{"padding": "6px 10px", "border": "1px solid #cbd5e1", "borderRadius": "4px", "fontFamily": "inherit", "width": "100%", "boxSizing": "border-box"}} />
      </div>
      <button type="submit">Submit</button>
    </form>
    <button id="NavUToDash" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardScreen")}>{"Dashboard"}</button>
    <button id="NavUToDashV2" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV2Screen")}>{"Dashboard v2"}</button>
    <button id="NavUToDashV3" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV3Screen")}>{"Dashboard v3"}</button>
    <button id="NavUToStarter" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/StarterScreen")}>{"Starter"}</button>
    <div id="UsersContent" style={{"width": "100%", "height": "auto", "padding": "24px", "margin": "0", "fontSize": "14px", "zIndex": 0, "background": "#F4F6F9", "color": "#1F2937", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "16px"}} />
    <DataListBlock id="UsersDataList" style={{"width": "100%", "height": "auto", "padding": "16px", "margin": "0 0 16px 0", "fontSize": "14px", "zIndex": 0, "background": "#FFFFFF", "color": "#1F2937", "borderColor": "#DEE2E6", "--chart-color-palette": "default"}} dataSources={[{"name": "UsersDataSource", "domain": "Users", "fields": ["usersShowingFrom", "usersShowingTo", "usersTotal"]}]} />
    <div id="UsersSidebar" style={{"width": "250px", "height": "100%", "padding": "0", "margin": "0", "fontSize": "14px", "top": "0", "left": "0", "bottom": "0", "zIndex": 50, "background": "#343A40", "color": "#C2C7D0", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "8px"}} />
    <div id="UsersTitle" style={{"width": "auto", "height": "auto", "padding": "0", "margin": "0 0 20px 0", "fontSize": "24px", "zIndex": 0, "color": "#1F2937", "--chart-color-palette": "default"}} />    </div>
  );
};

export default AdminlteUsersManagementPageUsersHtml;
