import React from "react";
import { useNavigate } from "react-router-dom";
import { DataListBlock } from "../components/runtime/DataListBlock";

const AdminlteDashboardV3Index3Html: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div id="DashboardV3Screen">
    <div id="DashV3Content" style={{"width": "100%", "height": "auto", "padding": "24px", "margin": "0", "fontSize": "14px", "zIndex": 0, "background": "#F4F6F9", "color": "#1F2937", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "16px"}} />
    <div id="DashV3Sidebar" style={{"width": "250px", "height": "100%", "padding": "0", "margin": "0", "fontSize": "14px", "top": "0", "left": "0", "bottom": "0", "zIndex": 50, "background": "#343A40", "color": "#C2C7D0", "--chart-color-palette": "default", "flexDirection": "column", "justifyContent": "left", "flexWrap": "wrap", "gap": "8px"}} />
    <DataListBlock id="DashV3StatsList" style={{"width": "100%", "height": "auto", "padding": "16px", "margin": "0 0 16px 0", "fontSize": "14px", "zIndex": 0, "background": "#FFFFFF", "color": "#1F2937", "borderColor": "#DEE2E6", "--chart-color-palette": "default"}} dataSources={[{"name": "DashV3DataSource", "domain": "DashboardV3", "fields": ["conversionRatePercent", "salesTotal", "visitorsChangePercent", "visitorsTotal"]}]} />
    <div id="DashV3Title" style={{"width": "auto", "height": "auto", "padding": "0", "margin": "0 0 20px 0", "fontSize": "24px", "zIndex": 0, "color": "#1F2937", "--chart-color-palette": "default"}} />
    <button id="Nav3ToDash" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardScreen")}>{"Dashboard"}</button>
    <button id="Nav3ToDashV2" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/DashboardV2Screen")}>{"Dashboard v2"}</button>
    <button id="Nav3ToStarter" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/StarterScreen")}>{"Starter"}</button>
    <button id="Nav3ToUsers" style={{"width": "100%", "height": "40px", "padding": "8px 16px", "margin": "0", "fontSize": "14px", "zIndex": 0, "color": "#C2C7D0", "--chart-color-palette": "default"}} onClick={() => navigate("/UsersScreen")}>{"Users"}</button>    </div>
  );
};

export default AdminlteDashboardV3Index3Html;
