import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { TableProvider } from "./contexts/TableContext";
import AdminlteMainDashboardIndexHtml from "./pages/AdminlteMainDashboardIndexHtml";
import AdminlteDashboardV2Index2Html from "./pages/AdminlteDashboardV2Index2Html";
import AdminlteDashboardV3Index3Html from "./pages/AdminlteDashboardV3Index3Html";
import AdminlteStarterPageStarterHtml from "./pages/AdminlteStarterPageStarterHtml";
import AdminlteUsersManagementPageUsersHtml from "./pages/AdminlteUsersManagementPageUsersHtml";

function App() {
  return (
    <TableProvider>
      <div className="app-container">
        <main className="app-main">
          <Routes>
            <Route path="/DashboardScreen" element={<AdminlteMainDashboardIndexHtml />} />
            <Route path="/DashboardV2Screen" element={<AdminlteDashboardV2Index2Html />} />
            <Route path="/DashboardV3Screen" element={<AdminlteDashboardV3Index3Html />} />
            <Route path="/StarterScreen" element={<AdminlteStarterPageStarterHtml />} />
            <Route path="/UsersScreen" element={<AdminlteUsersManagementPageUsersHtml />} />
            <Route path="/" element={<Navigate to="/DashboardScreen" replace />} />
            <Route path="*" element={<Navigate to="/DashboardScreen" replace />} />
          </Routes>
        </main>
      </div>
    </TableProvider>
  );
}
export default App;
